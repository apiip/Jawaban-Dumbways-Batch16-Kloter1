<?php 
    require("../config/db.php");

    // $baca = mysqli_query($koneksi, "SELECT tblbuku.nama as 'nama', tblbuku.pubyear as 'tanggal', tblcat.nama as 'jenis', tblwrite.nama as 'penulis' FROM tblbuku inner join tblcat on tblbuku.idcat = tblcat.id
    // inner join tblwrite on tblbuku.idwrite = tblwrite.id ");
    // $data = mysqli_query($koneksi, "SELECT * FROM tblbuku");
    // // kalo buat kombo box pilihan pake fetch all enak
    // $categories = mysqli_fetch_assoc($baca);
    $id = $_GET['id'];
    $edit = mysqli_query($koneksi, "SELECT foods.*, foods.id as 'id', foods.nama as 'nama', foods.stok as 'stok', categories.nama as 'jenis'
    FROM foods inner join categories on foods.idkat = categories.id
    where foods.id = $id");
    $edit = mysqli_fetch_assoc($edit);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="../style.css">
    <title>Detail</title>
</head>
<body>
<!-- start nav -->
<div class="container m-4">
<a href="../index.php" class="bttn">Hompage</a>
</div>
<!-- end nav -->
<!-- start content -->
<!-- isi -->
<div class="container pager m-4">
<div class="row container">
        <div class="col-md4">
        <div class="card" style="width: 18rem;">
        
            <img src="../foto/download.png" class="card-img-top" alt="...">
            <div class="card-body">
            <h5 class="card-title"><?php echo $edit['nama']; ?></h5>
            <p>Stok : <?php echo $edit['stok']; ?></p>
            <p>Jenis : <?php echo $edit['jenis']; ?></p>
            <a href="edit.php?id=<?=$edit['id']?>" class="btn btn-primary ebutton">Edit</a> |
            <a href="../config/dmenu.php?id=<?=$edit['id']?>" class="btn btn-danger" onclick="return confirm('Yakin Hapus Data Ini?');">Delete</a>
            </div>
        
        </div>
        </div>
</div>
</div>
<!-- end content -->

</body>


<!-- script -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="script.js"></script>
<!-- end script -->
</html>