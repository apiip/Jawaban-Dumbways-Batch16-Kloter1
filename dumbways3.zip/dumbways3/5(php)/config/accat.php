<?php 
    require('db.php');

    $nama = $_POST['nama'];
    mysqli_query($koneksi, "INSERT INTO tblcat(nama) VALUES('$nama')");

    // redirect
    header('location: ../index.php')
?>