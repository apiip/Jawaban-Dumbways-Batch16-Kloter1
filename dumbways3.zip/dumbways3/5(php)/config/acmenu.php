<?php 
    require('db.php');

    $nama = $_POST['nama'];
    $stok = $_POST['stok'];
    $jenis = $_POST['jenis'];
    $deskripsi = $_POST['deskripsi'];

    mysqli_query($koneksi, "INSERT INTO foods(idkat,nama,stok,deskripsi) VALUES('$jenis','$nama','$stok','$deskripsi')");
    // redirect
    header('location: ../index.php')
?>