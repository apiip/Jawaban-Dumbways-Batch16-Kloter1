<?php 
    require('db.php');

    $nama = $_POST['nama'];
    mysqli_query($koneksi, "INSERT INTO categories(nama) VALUES('$nama')");

    // redirect
    header('location: ../pages/kategori.php')
?>