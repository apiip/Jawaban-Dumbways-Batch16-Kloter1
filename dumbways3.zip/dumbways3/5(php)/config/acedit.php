<?php 
    require("db.php");

    $title = $_POST['nama'];
    $content = $_POST['stok'];
    $category_id = $_POST['penulis'];
    $deskripsi = $_POST['deskripsi'];
    $id = $_POST['id'];

    mysqli_query($koneksi, "UPDATE foods SET nama ='$title', stok ='$content', idkat ='$category_id', deskripsi ='$deskripsi' WHERE id = $id ");

    header('location: ../index.php')
?>