<?php 
   $koneksi = mysqli_connect("localhost", "root", "", "dbway3");

   if (!$koneksi) {
       echo "gagal koneksi";
   }
?>