<?php 
    require("./config/db.php");

    // sayur
    $baca = mysqli_query($koneksi, "SELECT nama, stok, deskripsi FROM foods where idkat = 1");
    $data = mysqli_query($koneksi, "SELECT * FROM foods where idkat = 1");
    // kalo buat kombo box pilihan pake fetch all enak
    $categories = mysqli_fetch_all($data, MYSQLI_ASSOC);

    // lauk kering
    $lauk2 = mysqli_query($koneksi, "SELECT nama, stok, deskripsi FROM foods where idkat = 3");
    $datakrg = mysqli_query($koneksi, "SELECT * FROM foods where idkat = 3");
    // kalo buat kombo box pilihan pake fetch all enak
    $kering = mysqli_fetch_all($datakrg, MYSQLI_ASSOC);

    // minuman
    $mnm = mysqli_query($koneksi, "SELECT nama, stok, deskripsi FROM foods where idkat = 2");
    $datamnm = mysqli_query($koneksi, "SELECT * FROM foods where idkat = 2");
    // kalo buat kombo box pilihan pake fetch all enak
    $mnm = mysqli_fetch_all($datamnm, MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Dumb Warteg</title>
</head>
<body>
<!-- start nav -->
<br>
<div class="container">
<h1>Dumb Warteg</h1> <br>
    <ul class="nav justify-content-end">
        <li class="">
        <a class="btn-danger bttn" href="./pages/ckategori.php">Tambah Kategori</a>
        </li>
        <li class="">
        <a class="btn-danger bttn" href="./pages/cmenu.php">Tambah Menu</a>
        </li>
    </ul>
</div>
<br><br>
<!-- end nav -->
<!-- start content -->
   
<!-- isi -->

<!-- Sayur -->
<div class="container alert alert-light">
<h4 class="alert alert-success">Sayur</h4>
<div class="row container pager">
    <?php if (mysqli_num_rows($data) > 0) { ?>
    <?php foreach($categories as $category) { ?>
        <div class="col-md4 pager">
        <div class="card" style="width: 15rem;">
        <img src="./foto/download.png" class="card-img-top" alt="...">
        <div class="card-body">
        <h5 class="card-title"><?php echo $category['nama']; ?></h5>
        <p><?php echo $category['deskripsi']; ?></p>
        <label id="stok" for="">Stok : <?php echo $category['stok']; ?> </label>

        <label for=""><?php if ($category['stok'] > 0) {
            echo '<span class="badge badge-primary">Tersedia</span>';
        } else {
            echo '<span class="badge badge-danger">Habis</span>';
        }?>
        </label>
        <br>
        <button type="button" class="btn btn-primary pesan" data-toggle="modal" data-target="#modalPesan" data-id="<?= $category['stok']; ?>" <?php if ($category['stok'] == '0'){ ?> disabled <?php   } ?> onclick=" addtocart(<?php echo $row['prod_id']; ?>)">Beli</button>
        <a href="./pages/detail.php?id=<?=$category['id']?>" id="coba" class="btn btn-primary coba">Detail</a>
        </div>
                        
    </div>
    </div>
    <?php } ?>

    <?php } else { ?>
        <h1> Maaf Belum Ada Data, Silahkan Ditambahkan </h1>
    <?php } ?>
</div>
</div>
<!-- end Sayur -->
<!-- Lauk Kering -->
<div class="container">
<h4 class="alert alert-info">Lauk Kering</h4>
<div class="row container pager">
    <?php if (mysqli_num_rows($datakrg) > 0) { ?>
    <?php foreach($kering as $category) { ?>
        <div class="col-md4 pager">
        <div class="card" style="width: 15rem;">
        <img src="./foto/download.png" class="card-img-top" alt="...">
        <div class="card-body">
        <h5 class="card-title"><?php echo $category['nama']; ?></h5>
        <p><?php echo $category['deskripsi']; ?></p>
        <label id="stok" for="">Stok : <?php echo $category['stok']; ?></label>
        
        <label for=""><?php if ($category['stok'] > 0) {
            echo '<span class="badge badge-primary">Tersedia</span>';
        } else {
            echo '<span class="badge badge-danger">Habis</span>';
        }?>
        </label>
        <br>
        <button type="button" class="btn btn-primary pesan" data-toggle="modal" data-target="#modalPesan" data-id="<?= $category['stok']; ?>" <?php if ($category['stok'] == '0'){ ?> disabled <?php   } ?> onclick=" addtocart(<?php echo $row['prod_id']; ?>)">Beli</button>
        <a href="./pages/detail.php?id=<?=$category['id']?>" id="coba" class="btn btn-primary coba">Detail</a>
        </div>
    </div>
    </div>
    <?php } ?>

    <?php } else { ?>
        <h1> Maaf Belum Ada Data, Silahkan Ditambahkan </h1>
    <?php } ?>
</div>
</div>
<!-- End Lauk Kering -->
<!-- minuman -->
<div class="container">
<h4 class="alert alert-dark">Minuman</h4>
<div class="row container pager">
    <?php if (mysqli_num_rows($datamnm) > 0) { ?>
    <?php foreach($mnm as $category) { ?>
        <div class="col-md4 pager">
        <div class="card" style="width: 15rem;">
        <img src="./foto/download.png" class="card-img-top" alt="...">
        <div class="card-body">
        <h5 class="card-title"><?php echo $category['nama']; ?></h5>
        <p><?php echo $category['deskripsi']; ?></p>
        <label id="stok" for="">Stok : <?php echo $category['stok']; ?></label>
        
        <label for=""><?php if ($category['stok'] > 0) {
            echo '<span class="badge badge-primary">Tersedia</span>';
        } else {
            echo '<span class="badge badge-danger">Habis</span>';
        }?>
        </label>
        <br>
        <button type="button" class="btn btn-primary pesan" data-toggle="modal" data-target="#modalPesan" data-id="<?= $category['stok']; ?>" <?php if ($category['stok'] == '0'){ ?> disabled <?php   } ?> onclick=" addtocart(<?php echo $row['prod_id']; ?>)">Beli</button>
        <a href="./pages/detail.php?id=<?=$category['id']?>" id="coba" class="btn btn-primary coba">Detail</a>
        </div>
                        
    </div>
    </div>
    <?php } ?>

    <?php } else { ?>
        <h1> Maaf Belum Ada Data, Silahkan Ditambahkan </h1>
    <?php } ?>
</div>
</div>

<!-- end Minuman -->
<!-- end content -->

<!-- modal -->
<!-- Modal -->
<div class="modal fade" id="modalPesan" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="judul">Perhatian</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p id="isiMod"></p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
<!-- end modal -->

</body>


<!-- script -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="script.js"></script>
<!-- end script -->
</html>